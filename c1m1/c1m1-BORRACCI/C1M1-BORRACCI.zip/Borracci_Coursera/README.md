/* Lucas Borracci - 06/15/2020 */

/* A simple C-Programming example that exhibits a handful of basic c-programming

 */ features to show how to calculate some statistics on a set of numbers:
	-Average
	-Maximum
	-Minimum
	-Number Histogram
	-Sort (Descending)

